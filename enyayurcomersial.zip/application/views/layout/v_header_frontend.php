<body class="hold-transition bg-light layout-top-nav">
    <div class="wrapper">