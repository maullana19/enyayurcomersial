<div class="card card-solid">
    <div class="card-body">
        akun saya
    </div>
</div>